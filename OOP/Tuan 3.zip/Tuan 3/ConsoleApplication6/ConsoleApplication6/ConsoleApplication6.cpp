﻿// ConsoleApplication6.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <string>
using namespace std;
#include "Giasuc.h"
using namespace std;

int random(int minN, int maxN) {
	return minN + rand() % (maxN + 1 - minN);
}
void xuat(Bo B, Cuu C, De D)
{
	cout << "Bo  So gia suc sinh ra la :" << B.sinhcon*B.sl << " So lit sua sx duoc " << B.litsua*B.sl << endl;
	cout << "Cuu  So gia suc sinh ra la :" << C.sinhcon*C.sl << " So lit sua sx duoc " << C.litsua*C.sl << endl;
	cout << "De  So gia suc sinh ra la :" << D.sinhcon*D.sl << " So lit sua sx duoc " << D.litsua*D.sl;
}
int main()
{
	srand((int)time(0));
	Bo B;
	Cuu C;
	De D;
	cout << "Nhap vao so luong bo ";
	B.nhap();
	B.get(random(1, 2), random(0, 20));
	cout << "Nhap vao so luong cuu ";
	C.nhap();
	C.get(random(1, 3), random(0, 5));
	cout << "Nhap vao so luong de ";
	D.nhap();
	D.get(random(1, 2), random(0, 10));
	cout << "Khi chu di vang nhung tieng keu nghe duoc se la ";
	B.call();
	C.call();
	D.call();
	xuat(B,C,D);
}

