#ifndef Giasuc_H
#define Giasuc_H
#include <iostream>
#include<string>
#pragma once
using namespace std;
class Giasuc
{
protected:
	
	string keu;
	
public:
	Giasuc() {};
	~Giasuc() {};
	int sinhcon,litsua;
	int sl;
	void nhap()
	{
		cin >> sl;
	}
	void call()
	{
		cout << keu << endl;
	}
	void get(int x, int y)
	{
		sinhcon = x;
		litsua = y;
	}
};	
class Bo :public Giasuc
{
public:
	Bo() { keu = "boooo"; };
	~Bo() {};
};
class Cuu :public Giasuc
{
public:
	Cuu() { keu = "eeeeee"; };
	~Cuu() {};
};
class De :public Giasuc
{
public:
	De() { keu = "beeeee"; };
	~De() {};
};
#endif
