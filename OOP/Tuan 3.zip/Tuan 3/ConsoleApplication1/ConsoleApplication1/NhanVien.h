#pragma once
#ifndef NhanVien_H
#define NhanVien_H
#include<iostream>
#include<string>
using namespace std;
class NhanVien
{
protected:
	string ten, ngaysinh;
	int luong;
public:
	NhanVien() {}
	~NhanVien() {}
	void input()
	{
		cout << "Nhap lan luot ten va ngay sinh cua nhan vien " << endl;
		cout << "Ten ";
		cin >> ten;
		cout<<"Ngay sinh ";
		cin >> ngaysinh;	
	}
	void xuat()
	{
		cout << "Ten " << ten << endl;
		cout << "Ngaysinh " << ngaysinh << endl;
		cout << "Luong " << luong << endl;

	}
	virtual void nhap() {}
	virtual int Salary() { return 10; };
};
class NhanVienSX:public NhanVien
{
protected:
	int luongcanban, sosanpham;
public:
	void nhap()
	{
		input();
		cout << "Luong can ban :";
		cin >> luongcanban;
		cout << "So san pham :";
		cin>>sosanpham;
		luong = luongcanban + sosanpham * 5000;
	}
};
class NhanVienVP :public NhanVien
{
protected:
	int songaylamviec;
public:
	void nhap()
	{
		input();
		cout << "So ngay lam viec ";
		cin >> songaylamviec;
		luong = songaylamviec * 100.000;
	}
};

#endif

