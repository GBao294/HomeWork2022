#include "NhanVien.h"
#include <iostream>
using namespace std;
void Nhap(NhanVien *a[], int n)
{

	int x;
	int i = 0;
	while (i < n)
	{
		cout << endl << "Nhan 1 de nhap NhanVienSX, nhan 2 de nhap vao NhanVienVP ";
		cin >> x;
		switch (x)
		{
		case 1:
		{	a[i] = new NhanVienSX;
		a[i]->nhap();
		break;
		}
		case 2:
			a[i] = new NhanVienVP;
			a[i]->nhap();
			break;
		}
		i++;
	}
}
void xuat(NhanVien *a[], int n)
{
	for (int i=0;i<n;i++)
	{
		a[i]->xuat();
	}
}
int main()
{
	NhanVien *A[100];
	cout << "Nhap vao so luong nhan vien cua cong ty :";
	int n;
	cin >> n;
	Nhap(A, n);
	xuat(A, n);
}
