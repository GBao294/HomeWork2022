#ifndef Diem_H
#define Diem_H
#include <iostream>
#pragma once
using namespace std;
class Diem
{
public:
	Diem() {};
	~Diem() {};
	float x, y;
};
class HinhTron :public Diem
{
private:
	Diem Tam;
	int r;
public:
	HinhTron() {};
	~HinhTron() {};
	void nhap()
	{
		cin>>x>>y >> r;
	}
	int getR()
	{
		return r;
	}
};
class Elip :public Diem
{
private :	
public :
	int a, b;
	Elip() {};
	~Elip() {};
	void nhap()
	{
		cin >> x >> y >> a>>b;
	}
};

#endif
