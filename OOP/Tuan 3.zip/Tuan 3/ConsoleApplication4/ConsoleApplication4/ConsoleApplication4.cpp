﻿#include <iostream>
#include "Diem.h"
#include <string>
#include "graphics.h"
#include<math.h>
#pragma comment(lib,"graphics.lib")
void VeCircle(HinhTron A)
{
	cout << "Nhap vao toa do x,y cua tam va ban kinh R " << endl;
		A.nhap();
	initwindow(1000, 1200, "ChuongTrinh", 50, 30);
	setcolor(15);
	circle(A.x, A.y, A.getR());
	getch();
	closegraph();
		
}
void Ve4diem(int xc, int yc, int x, int y, int color)//ve 4 diem doi xung
{
	putpixel(xc + x, yc + y, color);
	putpixel(xc - x, yc + y, color);
	putpixel(xc - x, yc - y, color);
	putpixel(xc + x, yc - y, color);
	delay(50);
}
void Elipse(int x_center, int y_center, int a, int b, int color)// ve elipse
{
	float p, a2, b2;
	int x, y;
	a2 = pow(a, 2);
	b2 = pow(b, 2);
	x = 0;
	y = b;
	p = 2 * ((float)b2 / a2) - (2 * b) + 1;

	//ve nhanh thu 1(tu tren xuong )
	while (((float)b2 / a2)*x <= y)
	{
		Ve4diem(y_center, y_center, x, y, color);
		if (p < 0)
		{
			p = p + 2 * ((float)b2 / a2)*(2 * x + 3);
		}
		else {
			p = p - 4 * y + 2 * ((float)b2 / a2)*(2 * x + 3);
			y--;
		}
		x++;
	}
	//ve nhanh thu 2(tu duoi len )
	y = 0;
	x = a;
	p = 2 * ((float)a2 / b2) - 2 * a + 1;
	while (((float)a2 / b2)*y <= x)
	{
		Ve4diem(y_center, y_center, x, y, color);
		if (p < 0)
		{
			p = p + 2 * ((float)a2 / b2)*(2 * y + 3);
		}
		else
		{
			p = p - 4 * x + 2 * ((float)a2 / b2)*(2 * y + 3);
			x = x - 1;
		}
		y = y + 1;
	}

}
void VeElip(Elip B)
{
	cout << "Nhap vao toa do tam cua elip va do dai a,b" << endl;
	B.nhap();
	initwindow(1000, 1200, "ChuongTrinh", 50, 30);
	Elipse(B.x, B.y, B.a, B.b, 15);
	getch();
}
int main()
{
	cout << "Nhap 1 de ve hinh tron , tuy y de ve hinh Elip";
	int n;
	cin >> n;
	if (n == 1) {
		HinhTron A;
		VeCircle(A);
	}
	else {
		Elip B;
		VeElip(B);
	}
	return 0;
}

