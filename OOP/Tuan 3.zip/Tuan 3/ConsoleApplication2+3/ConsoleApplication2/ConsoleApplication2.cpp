﻿#include <iostream>
#include "Nguoi.h"
using namespace std;
void Nhap(Nguoi *a[], int n)
{

	int x;
	int i = 0;
	while (i < n)
	{
		cout << endl << "Nhan 1 de nhap SinhVien, nhan 2 de nhap vao HocSinh,3 CongNhan, 4 NgheSi, 5 CaSi ";
		cin >> x;
		switch (x)
		{
		case 1:
		{	a[i] = new SinhVien;
		a[i]->nhap();
		break;
		}
		case 2:
			a[i] = new HocSinh;
			a[i]->nhap();
			break;
		case 3:
			a[i] = new CongNhan;
			a[i]->nhap();
			break;
		case 4:
			a[i] = new NgheSi;
			a[i]->nhap();
			break;
		case 5:
			a[i] = new CaSi;
			a[i]->nhap();
			break;
		}
		i++;
	}
}
void Xuat(Nguoi *A[], int n)
{
	for (int i = 0; i < n; i++)
		A[i]->xuat();
}
int main()
{
	Nguoi *A[100];
	int n;
	cout << "Nhap vao so luong nguoi :";
	cin >> n;
	Nhap(A, n);
	Xuat(A, n);
}