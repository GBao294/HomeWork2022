#ifndef Nguoi_H
#define Nguoi_H
#include<iostream>
#include<string>
using namespace std;
#pragma once
class Nguoi
{
protected:
	string ten, tuoi;
	string loai;
public:
	void nhap()
	{
		cout << "Nhap vao ten ";
		cin >> ten;
		cout << "Nhap vao tuoi ";
		cin >> tuoi;
	}
	void xuat()
	{
		cout << "Ten " << ten << " Tuoi: " << tuoi << " Nghe nghiep :" << loai << endl;
	}
	void getloai()
	{
		cout<<loai;
	}
};
class SinhVien :public Nguoi
{
private:
public:
	SinhVien() :Nguoi() {
		{
			loai = { "SinhVien" };
		}
	}
	~SinhVien() {}
};
class HocSinh :public Nguoi
{
private:
	
public:
	HocSinh() :Nguoi() {loai = "HocSinh";}
	~HocSinh() {}

}; 
class CongNhan :public Nguoi
{
private:
	
public:
	CongNhan() :Nguoi() { loai = "CongNhan";}
	~CongNhan() {}

};
class NgheSi :public Nguoi
{
private:
	
public:
	NgheSi() :Nguoi() { loai = "NgheSi";}
	~NgheSi() {}

};
class CaSi :public Nguoi
{
private:
	
public:
	CaSi() :Nguoi() {loai = "CaSi";}
	~CaSi() {}

};
#endif 